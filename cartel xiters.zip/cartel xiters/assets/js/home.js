document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menuToggle');
    const offCanvasWrapper = document.getElementById('offCanvasWrapper');
    const offCanvasOverlay = document.getElementById('offCanvasOverlay');
    const offCanvasClose = document.getElementById('offCanvasClose');
    const body = document.body;
    
    // Abrir menú offcanvas
    menuToggle.addEventListener('click', function() {
        offCanvasWrapper.classList.add('active');
        offCanvasOverlay.classList.add('active');
        body.style.overflow = 'hidden';
        
        // Animación para los spans del menú hamburguesa
        const spans = this.querySelectorAll('span');
        spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
    });
    
    // Cerrar menú offcanvas
    function closeOffCanvas() {
        offCanvasWrapper.classList.remove('active');
        offCanvasOverlay.classList.remove('active');
        body.style.overflow = '';
        
        // Restaurar icono hamburguesa
        const spans = menuToggle.querySelectorAll('span');
        spans.forEach(span => {
            span.style.transform = '';
            span.style.opacity = '';
        });
    }
    
    // Eventos para cerrar el menú
    offCanvasClose.addEventListener('click', closeOffCanvas);
    offCanvasOverlay.addEventListener('click', closeOffCanvas);
    
    // Cerrar al hacer clic en enlaces del menú
    const menuLinks = document.querySelectorAll('.offCanvas__contact a, .offCanvas__social-wrapper a');
    menuLinks.forEach(link => {
        link.addEventListener('click', closeOffCanvas);
    });
    
    // Cerrar con tecla ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeOffCanvas();
        }
    });

    // Eventos para los botones
    document.querySelector('.custom-btn').addEventListener('click', function() {
        window.location.href = 'https://discord.gg/cartelxiters';
    });

    document.querySelector('.tg-border-btn').addEventListener('click', function() {
        window.location.href = '/login';
    });
});

// Galeria Slider
document.addEventListener('DOMContentLoaded', function() {
    const track = document.querySelector('.gallery-track');
    const slides = document.querySelectorAll('.gallery-slide');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    let currentIndex = 1;
    const itemWidth = 1280 + 20;
    
    function updateSlider() {
        slides.forEach(slide => slide.classList.remove('center'));
        slides[currentIndex].classList.add('center');
        
        const offset = -currentIndex * itemWidth + (window.innerWidth / 2 - itemWidth / 2);
        track.style.transform = `translateX(${offset}px)`;
    }
    
    function moveToPrev() {
        if (currentIndex > 0) {
            currentIndex--;
            updateSlider();
        }
    }
    
    function moveToNext() {
        if (currentIndex < slides.length - 1) {
            currentIndex++;
            updateSlider();
        }
    }
    
    prevBtn.addEventListener('click', moveToPrev);
    nextBtn.addEventListener('click', moveToNext);
    
    updateSlider();
    
    document.addEventListener('keydown', function(e) {
        if (e.key === 'ArrowLeft') moveToPrev();
        else if (e.key === 'ArrowRight') moveToNext();
    });
});

document.querySelector('.popup-video').addEventListener('click', function() {
    // Lógica para abrir o vídeo em popup
    alert('Aqui você implementaria o player de vídeo modal');
});

let lastScroll = 0;

window.addEventListener('scroll', function () {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll <= 0) {
        document.body.classList.remove('scroll-up');
        return;
    }

    if (currentScroll > lastScroll) {
        // Rolando para baixo
        document.body.classList.remove('scroll-up');
        document.body.classList.add('scroll-down');
    } else {
        // Rolando para cima
        document.body.classList.remove('scroll-down');
        document.body.classList.add('scroll-up');
    }

    lastScroll = currentScroll;
});

